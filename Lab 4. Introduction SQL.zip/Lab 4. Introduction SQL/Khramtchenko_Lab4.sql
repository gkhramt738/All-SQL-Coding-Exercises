CREATE DATABASE World;
USE World;

SELECT * FROM City;
SELECT * FROM Country;
SELECT * FROM CountryLanguage;

-- Show all the tables in the system
SHOW tables;

-- Show all the columns that exist in that table
SHOW columns FROM City;

-- 1.	What fields does the Country table have?
Describe Country;

-- 6.	What are the first 3 cities in the database?
SELECT * FROM City
LIMIT 3;

-- 7.	What are the 3 most populous countries in the world?
SELECT Name, population
FROM Country
ORDER BY population DESC
LIMIT 3;

-- 8.	What is the smallest country in the world? How big is the country?
SELECT Name, SurfaceArea 
FROM Country
ORDER BY SurfaceArea ASC;