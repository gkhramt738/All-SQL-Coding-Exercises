# Create and use the Students Database 
-- CREATE DATABASE Students;
-- USE Students;

-- # Create Student table
-- CREATE TABLE Student(
-- student_id DECIMAL(12),
-- first_name VARCHAR(256),
-- last_name VARCHAR(256)
-- );

# Insert values into Student table
-- INSERT INTO Student (student_id, first_name, last_name)
-- VALUES (1, 'John', 'Smith');

-- # Select all rows in the table
-- SELECT * FROM Student;

# Update the last name of John Smith from “Smith” to “Williams” 
-- UPDATE Student SET last_name = 'Williams';

-- # Select all rows in the table again
-- SELECT * FROM Student;

# Remove all rows from the Student table, show table
DELETE FROM Student;  
SELECT * FROM Student;