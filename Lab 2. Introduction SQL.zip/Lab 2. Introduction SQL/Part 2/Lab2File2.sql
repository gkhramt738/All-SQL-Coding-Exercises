# Create and use the Books Database 
-- CREATE DATABASE Books;
-- USE Books;

# Create Book table
-- CREATE TABLE Book(
-- book_id DECIMAL(12),
-- title VARCHAR(256),
-- subtitle VARCHAR(256)
-- );

# Insert values into Student table
-- INSERT INTO Book (book_id, title, subtitle)
-- VALUES (101, 'Art', 'Modernized');

-- # Select all rows in the Book table
-- SELECT * FROM Book;

# Update the subtitle of "Modernized" to "Revisited” 
-- UPDATE Book SET subtitle = 'Revisited';

-- # Select all rows in the table again
SELECT * FROM Book;