-- Create and use the Resorts database
DROP DATABASE IF EXISTS Resorts;
CREATE DATABASE Resorts;
USE Resorts;

-- Create Resort table
DROP TABLE IF EXISTS Resort;
CREATE TABLE Resort(
	resort_id Decimal(12) Primary Key,
    resort_type_id Decimal(12) NOT NULL,
    name VARCHAR(64) NOT NULL
);

-- Create Resort_Type table
DROP TABLE IF EXISTS Resort_Type;
CREATE TABLE Resort_Type(
	resort_type_id Decimal(12) Primary Key,
    resort_type VARCHAR(255) NOT NULL
);

-- Create Accommodations table
DROP TABLE IF EXISTS Accommodations;
CREATE TABLE Accommodations(
	accommodations_id Decimal(12) Primary Key,
    resort_id Decimal(12)  NOT NULL,
    description_type VARCHAR(255) NOT NULL,
    cost_per_night DECIMAL(10,2) NULL
);

-- Insert initial data into the Resort_Type table
INSERT INTO Resort_Type (resort_type_id, resort_type)
VALUES
(1, 'Ocean'),
(2, 'Lakeside'),
(3, 'Mountaintop'),
(4, 'County');

-- Insert initial data into the Resort table
INSERT INTO Resort (resort_id, resort_type_id, name)
VALUES
(10, 1, 'Light of the ocean'),
(11, 1, 'Breaking Bahamas');

-- Insert initial data into the Accommodations table
INSERT INTO Accommodations (accommodations_id, resort_id, description_type, cost_per_night)
VALUES
(20, 10, 'Bungalow', 289),
(21, 10, 'Bungalow2', 289),
(22, 10, 'Bungalow3', 325),
(23, 11, 'Suite101', 299),
(24, 11, 'Suite201', 399),
(25, 11, 'Suite301', 499),
(26, 11, 'Suite401', 599);

-- 5. Insert 10 new accomodations into the accomodations table
INSERT INTO Accommodations (accommodations_id, resort_id, description_type, cost_per_night)
VALUES
(27, 11, 'Suite402', 550),
(28, 11, 'Suite403', 550),
(29, 11, 'Suite404', 550),
(30, 11, 'Suite405', 550),
(31, 11, 'Suite405', 550),
(32, 10, 'Bungalow4', 350),
(33, 10, 'Bungalow5', 350),
(34, 10, 'Bungalow6', 350),
(35, 10, 'Bungalow7', 350),
(36, 10, 'Bungalow8', 350);

-- 7. Display the total count of accomodation IDs
SELECT COUNT(accommodations_id)
FROM Accommodations;

-- 9. Display the top five most cost-effective accommodations at the resort
SELECT accommodations_id, resort_id, description_type, cost_per_night
FROM Accommodations
ORDER BY cost_per_night ASC
LIMIT 5;

-- 10. Display the top five most expensive accommodations at the resort
SELECT accommodations_id, resort_id, description_type, cost_per_night
FROM Accommodations
ORDER BY cost_per_night DESC
LIMIT 5;

-- 11. Display the sum of the total cost of accommodations at the resort
SELECT SUM(cost_per_night)
FROM Accommodations;
