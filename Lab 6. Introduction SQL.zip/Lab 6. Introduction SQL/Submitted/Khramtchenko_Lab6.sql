-- Create and use the Movies database
DROP DATABASE IF EXISTS Movies;
CREATE DATABASE Movies;
USE Movies;

-- Create the movies_basic table
DROP TABLE IF EXISTS movies_basic;
CREATE TABLE movies_basic
(id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
title VARCHAR(100),
genre VARCHAR(20),
release_year INT,
director VARCHAR(40),
studio VARCHAR(30),
critics_rating DECIMAL(2,1) Default 0);

-- Alter the movies_basic table
ALTER TABLE movies_basic
ADD COLUMN box_office_gross FLOAT,
RENAME COLUMN critics_rating TO critic_rating, 
CHANGE COLUMN director director VARCHAR(50);

-- Alter the movies_basic table to change the director column to varchar 40
ALTER TABLE movies_basic
CHANGE COLUMN director director VARCHAR(40);

-- Manually insert data into the movies_basic table (data import failed)
INSERT INTO movies_basic (title, genre, release_year, director, studio, critic_rating)
VALUES ('Coat Of Mysteries', 'Children', 1901, 'Julian Fowler', 'Studio 60', 5.5),
	   ('Students And Boys', 'Horror', 1903, 'Julian Fowler', 'Bix,', 3.4),
       ('Created By The End', 'Sci-Fi', 1910, 'Rebecca Adams', 'Falstead Group', 5.9),
       ('Men And Traitors', 'Sci-Fi', 1912, 'Julian Fowler', 'Arpeggio Brothers', 3.2),
       ('Hunters Of Eternity', 'Sci-Fi', 1913, 'Ryan Ross', 'Torchwood', 7);

-- Display all movies from the movies_basic table
SELECT * FROM movies_basic;

-- Part 2: 

-- Display movie with ID of 1
Select * FROM movies_basic
WHERE id = 1;

-- Display movie of the children genre
Select * FROM movies_basic
WHERE genre LIKE ‘Children’;

-- Display movie which comes from the studio specified
Select * FROM movies_basic
WHERE studio LIKE ‘Studio’;

-- Display movie which has release year in the 1980s
Select * FROM movies_basic
WHERE release_year LIKE ‘198’;

-- Display movie which have a critic rating greater than 6 and are a drama movie.
SELECT * FROM movies_basic
WHERE genre LIKE 'drama' and critic_rating > 6;

-- Display movie which have a critic rating less than 6 and are a drama movie.
SELECT * FROM movies_basic
WHERE genre LIKE 'drama' and critic_rating < 6;

-- Display movie which have a critic rating less than 6 o are a drama movie.
SELECT * FROM movies_basic
WHERE genre LIKE 'drama' OR critic_rating < 6;