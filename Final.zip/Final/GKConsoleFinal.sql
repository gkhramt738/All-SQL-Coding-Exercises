DROP DATABASE if exists MovieCompany;
CREATE DATABASE MovieCompany;
USE MovieCompany;

DROP TABLE if exists movies_actors_association;
DROP TABLE if exists actors;
DROP TABLE if exists movies;
DROP TABLE if exists directors;

# Table 2: ‘Directors’
# Column: ‘first_name’
# Column: ‘last_name’
# Additional columns if you choose

CREATE TABLE directors (
    director_id int NOT NULL,
    first_name varchar (15),
    last_name varchar (20),
    nationality varchar (20),
    PRIMARY KEY (director_id)
);

# Table 1: ‘Movies’
# Column: ‘title’
# Column: ‘release_year’
# Column: ‘genre’
# Additional columns if you choose

CREATE TABLE movies (
    movie_id int NOT NULL,
    director_id int NOT NULL,
    title varchar (30),
    release_year int NOT NULL,
    genre varchar (20),
    PRIMARY KEY (movie_id),
    FOREIGN KEY (director_id) references directors (director_id)
);

# Table 3: ‘Actors’
# Column: ‘first_name’
# Column: ‘last_name’

 CREATE TABLE actors (
    actor_id int NOT NULL,
    first_name varchar (15),
    last_name varchar (20),
    PRIMARY KEY (actor_id)
 );

# There should be a one-many relationship between movies and directors (a movie can have only one director, a director can direct multiple movies)
# There should be a many-many relationship between movies and actors (a movie can have multiple actors, an actor can be in multiple movies)
# Create additional tables as you see fit to create necessary relationships

CREATE TABLE movies_actors_association (
    id int NOT NULL UNIQUE AUTO_INCREMENT,
    movie_id int NOT NULL,
	actor_id int NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (actor_id) references actors (actor_id),
    FOREIGN KEY (movie_id) references movies (movie_id)
);

# Insert data
ALTER TABLE directors CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
INSERT INTO directors (director_id, first_name, last_name, nationality) VALUES (1, 'Pierre', 'Perifel', 'French');
INSERT INTO directors (director_id, first_name, last_name, nationality) VALUES (2, 'Steven ', 'Spielberg', 'American');
INSERT INTO directors (director_id, first_name, last_name, nationality) VALUES (3, 'Ridley', 'Scott', 'English');

INSERT INTO movies (movie_id, director_id, title, release_year, genre) VALUES (1, 1, 'Bad Guys', 2022, 'Comedy');
INSERT INTO movies (movie_id, director_id, title, release_year, genre) VALUES (2, 2, 'Schindlers List', 1993, 'History');
INSERT INTO movies (movie_id, director_id, title, release_year, genre) VALUES (3, 3, 'The Martian', 2015, 'Drama');

INSERT INTO actors (actor_id, first_name, last_name) VALUES (1, 'Sam', 'Rockwell');
INSERT INTO actors (actor_id, first_name, last_name) VALUES (2, 'Richard', 'Ayoade');
INSERT INTO actors (actor_id, first_name, last_name) VALUES (3, 'Liam', 'Neeson');
INSERT INTO actors (actor_id, first_name, last_name) VALUES (4, 'Ralph', 'Fiennes');
INSERT INTO actors (actor_id, first_name, last_name) VALUES (5, 'Matt', 'Damon');
INSERT INTO actors (actor_id, first_name, last_name) VALUES (6, 'Jessica', 'Chastain');

INSERT INTO movies_actors_association (movie_id, actor_id) VALUES (1, 1);
INSERT INTO movies_actors_association (movie_id, actor_id) VALUES (1, 2);
INSERT INTO movies_actors_association (movie_id, actor_id) VALUES (2, 3);
INSERT INTO movies_actors_association (movie_id, actor_id) VALUES (2, 4);
INSERT INTO movies_actors_association (movie_id, actor_id) VALUES (3, 5);
INSERT INTO movies_actors_association (movie_id, actor_id) VALUES (3, 6);

# Queries
SELECT * FROM movies;
SELECT * FROM actors;
SELECT * FROM directors;
SELECT * FROM movies_actors_association;

# Select the first and last name of all actors who were in any movie where the genre was ‘comedy’
SELECT a.first_name, a.last_name
FROM movies m, actors a, movies_actors_association maa
WHERE m.movie_id = maa.movie_id
  AND a.actor_id = maa.actor_id
  AND genre = 'Comedy';

# Select exactly one director, whose name is “steven spielberg”
SELECT * FROM directors
WHERE first_name = 'Steven' AND last_name = 'Spielberg';

# Select the director's first name, director’s last name, movie title, and movie genre for all movies with a release year of ‘2015’
SELECT d.first_name, d.last_name, m.title, m.genre, m.release_year
FROM directors d, movies m
WHERE d.director_id = m.director_id
  AND m.release_year = 2015
