create table actors
(
    actor_id   int         not null
        primary key,
    first_name varchar(15) null,
    last_name  varchar(20) null
);

create table directors
(
    director_id int         not null
        primary key,
    first_name  varchar(15) null,
    last_name   varchar(20) null,
    nationality varchar(20) null
)
    collate = utf8mb4_unicode_ci;

create table movies
(
    movie_id     int         not null
        primary key,
    director_id  int         not null,
    title        varchar(30) null,
    release_year int         not null,
    genre        varchar(20) null,
    constraint movies_ibfk_1
        foreign key (director_id) references directors (director_id)
);

create index director_id
    on movies (director_id);

create table movies_actors_association
(
    id       int auto_increment
        primary key,
    movie_id int not null,
    actor_id int not null,
    constraint id
        unique (id),
    constraint movies_actors_association_ibfk_1
        foreign key (actor_id) references actors (actor_id),
    constraint movies_actors_association_ibfk_2
        foreign key (movie_id) references movies (movie_id)
);

create index actor_id
    on movies_actors_association (actor_id);

create index movie_id
    on movies_actors_association (movie_id);


