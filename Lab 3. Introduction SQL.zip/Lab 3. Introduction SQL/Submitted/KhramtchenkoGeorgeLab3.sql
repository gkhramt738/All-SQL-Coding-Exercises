-- Drop the Albums database and Album table if it already exists
DROP  TABLE IF EXISTS Album;
DROP DATABASE IF EXISTS Albums;

--  Create and use the the Albums Datbase
CREATE DATABASE Albums;
USE Albums;

-- Create the Album table containing album titles and their attributes
CREATE TABLE Album (
album_id DECIMAL(12) PRIMARY KEY,
musical_genre VARCHAR(50) NOT NULL,
recording_artist VARCHAR(64) NOT NULL,
album_name VARCHAR(64) NOT NULL,
suggested_price NUMERIC(8,2) NULL
);

-- Insert a row with values album_id=1, musical_genre=hip hop, recording_artist=rick ross, album_name=port of miami, suggested_price=$16.00 
INSERT INTO Album (album_id, musical_genre, recording_artist, album_name, suggested_price)
VALUES(1, 'hip hop', 'rick ross', 'port of miami', 16);

-- Populate the Album table with 10 new albums using the attribute names specified during table creation
INSERT INTO Album (album_id, musical_genre, recording_artist, album_name, suggested_price)
VALUES
(2, 'rock and roll', 'led zeppelin', 'some album', 18),
(3, 'pop', 'taylor swift', 'eras', 24),
(4, 'funk', 'junk boys', 'fun punk', 32),
(5, 'hip hop', 'some artist', 'black and blue', 28),
(6, 'rock', 'john doorman', 'JJS', 12),
(7, 'jazz', 'john coltrane', 'my favorite things', 14),
(8, 'rap', 'pop smoke', 'faith', 22),
(9, 'pop', 'taylor swift', 'the tortured poets department', 40),
(10, 'rap', 'eminem', 'the eminem show', 13),
(11, 'rap', 'eminem', 'Encore', 11);

-- Display the entire Album table
SELECT * FROM Album;

-- Update the album “Port of Miami” to “Port of Miami 2”
UPDATE Album
SET album_name = 'port of miami 2';

-- 1.	Execute the command to insert a new row with a musical_genre of Heavy Metal
INSERT INTO Album (album_id, musical_genre, recording_artist, album_name, suggested_price)
VALUES (12, 'Heavy Metal', 'Metallica', 'Metallica', 11);

-- 3.	Update the musical_genre to pop
UPDATE Album
SET musical_genre = 'pop';

-- 4.	Remove the last two rows from the album table
DELETE FROM Album
ORDER BY album_id desc limit 2;

-- 6. Attempt to select all the rows from the table
SELECT * FROM Album;

-- 7.	Attempt to select only hip hop musical_genres 
SELECT * FROM Album WHERE musical_genre = 'hip hop';