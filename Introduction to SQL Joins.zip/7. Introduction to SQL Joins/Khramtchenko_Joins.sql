-- Use the World database already in existence
USE World;

-- Display current City table
SELECT * FROM City;

-- 1. Using SQL add your hometown to the City table or, add another City to the City table.
INSERT INTO City(Name,CountryCode,District,Population) VALUES ('Acton','USA','Acton',30000);

-- 2. Update the City you added to the database.
UPDATE City
SET Name = 'Boxborough', District = 'Boxborough'
WHERE Name = 'Acton';

-- 3. Update the city population, and display the changes to provide a screenshot of the change.
UPDATE City
SET Population = 25000
WHERE Name = 'Boxborough';

SELECT * FROM City
WHERE Name = 'Boxborough';

-- 4. List the City names and City population in Laos.
SELECT Co.Name, C.Name, C.Population
FROM Country co, city c
WHERE Co.Code = C.CountryCode
AND Co.Name = 'Laos';

-- 5. In a few sentences explain how we find the name of the capital city for each country?
-- To find the name of the capital city for each country, we would need to join the city and country table to then lookup the capital city for each country.

-- 6. List the country name and capital city name, for all countries in Asia.
SELECT Co.Name, C.Name AS Capital_City
FROM Country co, City c
WHERE Co.Code = C.CountryCode AND Co.Capital = c.ID AND Co.Continent = 'Asia';

-- 7. How can we join the CountryLanguage table with the Country table?
SELECT * FROM CountryLanguage
JOIN Country
ON CountryLanguage.CountryCode = Country.Code;

-- 8. In what countries is the Thai language spoken? By what percentage of the people? LAOS, Thailand, Vietnam
SELECT Country.Name, CountryLanguage.Percentage
FROM Country
JOIN CountryLanguage
ON CountryLanguage.CountryCode = Country.Code
WHERE CountryLanguage.Language = 'Thai';

-- 9. What countries speak/use English?
SELECT Country.Name, CountryLanguage.Language
FROM Country
JOIN CountryLanguage
ON CountryLanguage.CountryCode = Country.Code
WHERE CountryLanguage.Language = 'English';

-- 10. In how many countries is English the official language?
SELECT COUNT(*) AS Countries_With_English_As_Official_Language
FROM Country
JOIN CountryLanguage
ON CountryLanguage.CountryCode = Country.Code
WHERE CountryLanguage.Language = 'English' AND IsOfficial = 'T';

-- 11. In the world, approximately how many people speak English?
SELECT Sum(Population) AS Approximate_World_English_Speakers
FROM Country
JOIN CountryLanguage
ON CountryLanguage.CountryCode = Country.Code
WHERE CountryLanguage.Language = 'English' AND IsOfficial = 'T';

SELECT Country.Name, CountryLanguage.Language, CountryLanguage.Percentage
FROM Country
JOIN CountryLanguage
ON Country.Code = CountryLanguage.CountryCode
WHERE Language = 'English'
ORDER BY Percentage DESC;

-- 12. Using Join, Join the Country and Language tables.
SELECT * FROM CountryLanguage
JOIN Country
ON CountryLanguage.CountryCode = Country.Code;

-- 13. View Country name and language with "SELECT..."
SELECT Name, Region, Language FROM CountryLanguage
JOIN Country
ON CountryLanguage.CountryCode = Country.Code;

-- 14. How many times is Thailand listed in the results?
SELECT COUNT(*) Times_Thailand_Is_Listed FROM CountryLanguage
JOIN Country
ON CountryLanguage.CountryCode = Country.Code
WHERE Name = 'Thailand';

-- 15. What steps would you take to order the results above by language?
SELECT Name, Region, Language FROM Country
JOIN CountryLanguage
ON Country.Code = CountryLanguage.CountryCode
WHERE Country.Name = 'Thailand'
ORDER BY Language;

-- 16. What is the total population of each continent?
SELECT Continent, SUM(Country.Population) AS Total_Population_Of_Each_Continent
FROM Country
GROUP BY Continent;

-- 17. How many countries have a government that is any form of monarchy?
SELECT COUNT(*) Government_Monarchy FROM Country
WHERE GovernmentForm LIKE '%Monarchy';

-- 18. How many are some form of monarchy, but not a Constitutional Monarchy (like Thailand)?
SELECT COUNT(*) Government_Monarchy FROM Country
WHERE GovernmentForm LIKE 'Monarchy%'
AND GovernmentForm NOT LIKE '%Constitutional';
