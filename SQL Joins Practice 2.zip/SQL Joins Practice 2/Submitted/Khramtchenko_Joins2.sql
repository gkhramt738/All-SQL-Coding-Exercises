-- Use the World database already in existence
USE World;

-- 1. What is the total population and total GNP of each continent?
SELECT
	Continent, SUM(Country.Population) AS Total_Population_Of_Each_Continent,
	SUM(Country.GNP) AS Total_GNP_Of_Each_Continent
FROM Country
GROUP BY Continent;

-- 2. What countries are the richest and poorest?
	SELECT Name, GNP/Population*1000000 as Per_Capita_Richest
    FROM Country
    ORDER BY Per_Capita_Richest
    DESC LIMIT 5;

-- Display the poorest countries by GNP
	SELECT Name, GNP/Population*1000000 as Per_Capita_Poorest
    FROM Country
    WHERE GNP/Population*1000000 NOT IN ('Null', '0.00000')
    ORDER BY Per_Capita_Poorest
	ASC LIMIT 5;

-- 3. What countries are the most crowded?
SELECT Name, Population/SurfaceArea AS most_crowded
FROM Country
ORDER BY most_crowded
DESC LIMIT 5;

-- 4. What countries use English?
SELECT Country.Name, CountryLanguage.Language, CountryLanguage.Percentage
FROM Country
JOIN CountryLanguage
ON CountryLanguage.CountryCode = Country.Code
WHERE CountryLanguage.Language = 'English'
ORDER BY Percentage DESC;

-- 5. In how many countries is English the official language?
SELECT COUNT(*) AS Countries_With_English_As_Official_Language
FROM Country
JOIN CountryLanguage
ON CountryLanguage.CountryCode = Country.Code
WHERE CountryLanguage.Language = 'English' AND IsOfficial = 'T';

-- 6. In the world, approximately how many people speak English?
SELECT Sum(Population) AS Approximate_World_English_Speakers
FROM Country
JOIN CountryLanguage
ON CountryLanguage.CountryCode = Country.Code
WHERE CountryLanguage.Language = 'English' AND IsOfficial = 'T';

-- 7. JOIN the Country and Language tables.
SELECT Country.Name, Country.Region, CountryLanguage.Language
FROM Country, CountryLanguage
WHERE CountryLanguage.CountryCode = Country.Code;

-- 8. How many countries have a government that is any form of monarchy?
SELECT COUNT(*) Government_Monarchy FROM Country
WHERE GovernmentForm LIKE '%Monarchy';