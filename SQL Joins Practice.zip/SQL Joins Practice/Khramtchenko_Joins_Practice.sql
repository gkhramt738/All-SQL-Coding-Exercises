-- Create and use the Bookstore database
CREATE DATABASE Bookstore;
USE Bookstore;

DROP TABLE IF EXISTS Books;
DROP TABLE IF EXISTS Authors;

-- 	SQL for creating authors table
CREATE TABLE Authors(
	AuthorID INT PRIMARY KEY,
    AuthorName VARCHAR(255) NOT NULL
);

-- 	SQL for creating books table
CREATE TABLE Books(
	BookID INT PRIMARY KEY,
    Title VARCHAR(255) NOT NULL,
    AuthorID INT,
    PublicationYear INT,
    FOREIGN KEY (AuthorID) REFERENCES Authors(AuthorID)
);

-- SQL DML insert data into Authors table
INSERT INTO Authors (AuthorID, AuthorName) VALUES
(1, 'J.K. Rowling'),
(2, 'George Orwell'),
(3, 'Jane Austen');

-- SQL DML insert data into Books table
INSERT INTO Books (BookID, Title, AuthorID, PublicationYear) VALUES
	(1, 'Harry Poter', 1, 1997),
    (2, '1984', 2, 1949),
    (3, 'Pride and Prejudice', 3, 1813),
    (4, 'Animal Farm', 2, 1945);

-- Join the Authors and Books table
    SELECT Books.Title, Authors.AuthorName, Books.PublicationYear
    FROM Books
    INNER JOIN Authors ON Books.AuthorID = Authors.AuthorID
    ORDER BY Books.PublicationYear;
    
-- Query to display all authors including authors who haven’t written any books.
    SELECT Books.Title, Authors.AuthorName, Books.PublicationYear
    FROM Authors
    LEFT JOIN Books ON Authors.AuthorID = Books.AuthorID
    ORDER BY Authors.AuthorName;