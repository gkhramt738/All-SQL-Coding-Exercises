-- Create and use Student database
CREATE DATABASE Student;
USE Student;

-- Create Student table with parameters Student_ID, Name, Major
DROP TABLE IF EXISTS Student;
CREATE TABLE Student(
	Student_ID INT PRIMARY KEY,
    Name VARCHAR(255),
    Major VARCHAR(255)
);

-- Create Course table with paramters Course_ID, Name, Credit_Hours
DROP TABLE IF EXISTS Course;
CREATE TABLE Course(
	Course_ID INT PRIMARY KEY,
    Name VARCHAR(255),
    Credit_Hours VARCHAR(255)
);

-- Create Tuition table with paramters Student_ID, Course_ID, Amount
DROP TABLE IF EXISTS Tuition;
CREATE TABLE Tuition(
	Student_ID INT PRIMARY KEY,
	Course_ID INT,
    Amount REAL
);

-- Insert data into Student table
INSERT INTO Student(Student_ID, Name, Major) VALUES
(1, 'John Smith', 'Computer Science'),
(2, 'Jane Doe', 'Biology'),
(3, 'Peter Parker', 'Chemistry'),
(4, 'Mary Jane', 'Computer Science');

-- Insert data into Course table
INSERT INTO Course(Course_ID, Name, Credit_Hours) VALUES
(1, 'Introduction to Computer Science', 4),
(2, 'Organic Chemistry', 3),
(3, 'Calculus I', 4),
(4, 'Data Structures', 4);

-- Insert data into Tuition table
INSERT INTO Tuition(Student_ID, Course_ID, Amount) VALUES
(1, 1, 1000),
(2, 4, 1200),
(3, 2, 900),
(4, 3, 800),
(5, 1, 1100);

-- Join the student and tuition tables and display the name, major, and tuition amount for each student.
SELECT Student.Name, Student.Major, Tuition.Amount
FROM Student
JOIN Tuition
ON Student.Student_ID = Tuition.Student_ID;

-- Join the course and tuition tables and display the course name, credit hours, and tuition amount for each course.
SELECT Course.Name, Course.Credit_Hours, Tuition.Amount
FROM Course
JOIN Tuition
ON Course.Course_ID = Tuition.Course_ID;

-- Join all three tables and display the name of the student, name of the course, and tuition amount for each student and course.
SELECT Student.Name, Course.Name, Tuition.Amount
FROM Student
JOIN Tuition
ON Student.Student_ID = Tuition.Student_ID
JOIN Course
ON Tuition.Course_ID = Course.Course_ID;

-- Join the student and course tables and display the name of the student, name of the course, and the number of credit hours for each course taken by each student. Include all students and courses, even if the student has not taken any courses.
SELECT Student.Name, Course.Name, COALESCE(Course.Credit_Hours, 0) as credit_hours
FROM Student
LEFT JOIN Tuition
ON Student.Student_ID = Tuition.Student_ID
LEFT JOIN Course
ON Tuition.Course_ID = Course.Course_ID
ORDER BY Student.Name, Course.Name;

